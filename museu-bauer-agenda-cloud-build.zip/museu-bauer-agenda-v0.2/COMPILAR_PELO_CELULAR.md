# Compilar o Museu Bauer Agenda usando somente o celular

Este projeto inclui um workflow de GitHub Actions que compila o APK na nuvem. A compilação só será executada depois que o projeto for enviado a um repositório GitHub.

## Passo a passo

1. No navegador do Android, abra https://github.com e crie uma conta ou entre na sua conta.
2. Crie um repositório novo chamado `museu-bauer-agenda`. Para um primeiro teste, pode ser privado.
3. Extraia o ZIP do projeto no celular usando o app Arquivos/Meus Arquivos.
4. Envie os arquivos e pastas extraídos para o repositório. É importante enviar o conteúdo do projeto, incluindo a pasta oculta `.github/workflows/android-apk.yml`, e não apenas o ZIP.
5. Abra a aba **Actions** no repositório e permita workflows se o GitHub solicitar.
6. Se a compilação não iniciar automaticamente, abra o workflow **Compilar APK Android**, toque em **Run workflow** e confirme.
7. Aguarde o trabalho terminar. Só considere compilado se o resultado estiver verde/success.
8. Abra a execução concluída, baixe o artefato `Museu-Bauer-Agenda-debug` e extraia o ZIP do artefato.
9. Toque em `app-debug.apk` para instalar. O Android poderá solicitar autorização para instalar apps dessa origem. Autorize somente se estiver no seu repositório e reconhecer a execução de compilação.
10. Abra o app, permita notificações e crie um lembrete de teste para 2–3 minutos no futuro.

## Teste de lembretes

- Crie um lembrete com título “Teste Museu Bauer” para 2–3 minutos à frente.
- Feche a tela do app e aguarde a notificação.
- Depois, reinicie o aparelho e crie outro lembrete futuro para testar a restauração.
- O modo de economia de bateria do fabricante pode atrasar notificações; confira as permissões se não chegar.

## Limitações importantes

- Este workflow gera um APK de depuração (debug), adequado para teste, não uma versão assinada para distribuição pública.
- O APK ainda não terá a conexão GPT funcionando até que o backend seja hospedado em HTTPS e configurado na tela do agente.
- O backend atual ainda não controla a agenda local via comandos estruturados.
- Não publique o backend sem autenticação. Não coloque chaves de API dentro do APK ou do repositório.
- Não é possível instalar o APK remotamente a partir do ChatGPT; a instalação precisa ser confirmada no próprio Android.
