import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import OpenAI from 'openai';

const app = express();
app.use(helmet());
app.use(express.json({ limit: '32kb' }));
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const agentInstructions = `Você é o Agente Gestor do Museu de História da Tecnologia do Cimol – Harald Alberto Bauer (Museu Mestre Bauer). Ajude a organizar rotinas, documentos, projetos e exposições, pesquisa histórica e conservação do acervo. Seja prático, use listas objetivas e destaque prioridades. Não afirme que criou ou alterou tarefas sem uma ferramenta real confirmar a ação. Neste protótipo, você ainda não tem acesso à agenda local nem ao Scopi.`;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'museu-bauer-gpt-backend' }));
app.post('/api/assistant', async (req, res) => {
  try {
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message || message.length > 8000) return res.status(400).json({ error: 'Envie uma mensagem de até 8000 caracteres.' });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: agentInstructions,
      input: message
    });
    res.json({ answer: response.output_text });
  } catch (error) {
    console.error('Falha na chamada de IA:', error?.message || 'erro desconhecido');
    res.status(500).json({ error: 'Não foi possível consultar o agente neste momento.' });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Museu Bauer backend disponível na porta ${port}`));
