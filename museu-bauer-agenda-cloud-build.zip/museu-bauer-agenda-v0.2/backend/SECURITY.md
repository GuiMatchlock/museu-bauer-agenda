# Segurança antes de publicar

- Nunca inclua `OPENAI_API_KEY` no APK nem em código Android.
- Hospede o backend atrás de HTTPS.
- Este protótipo ainda não possui autenticação do usuário nem limitação de requisições; não o publique abertamente.
- Antes de uso real, adicione autenticação, rate limiting, limites de custo e logs sem dados sensíveis.
- A API atual apenas conversa com o modelo; ela não altera a agenda local nem acessa o Scopi.
- Mantenha a integração Scopi em modo somente leitura inicialmente e exija confirmação humana para qualquer escrita.
