# Museu Bauer Agenda — protótipo inicial

Projeto-fonte de um aplicativo Android para agenda, tarefas e lembretes do Museu Mestre Bauer, com um serviço backend opcional para integração segura com a API da OpenAI.

## O que já está preparado
- Interface Android em Kotlin + Jetpack Compose.
- Cadastro local de tarefas com seleção de data e hora específicas e prioridade.
- Notificações locais agendadas no dispositivo; alarmes exatos quando o Android permite, com alternativa compatível.
- Reagendamento dos lembretes após reinicialização do aparelho ou atualização do app.
- Cancelamento de lembretes ao concluir ou excluir uma tarefa.
- Tela de conversa GPT que usa um backend HTTPS configurável e mantém a chave da OpenAI no servidor.
- Estrutura inicial de backend Node.js para conversar com a API da OpenAI sem colocar a chave no aplicativo.
- Orientações para uma futura integração com o Scopi.

## Limitações deste protótipo
- Ainda não é um APK instalado/assinado; é o projeto-fonte para abrir no Android Studio.
- A conversa com GPT requer configurar e hospedar o backend com uma chave de API da OpenAI.
- O endereço do backend deve usar HTTPS; conexões HTTP sem criptografia são bloqueadas pelo app.
- A sincronização com Scopi ainda não foi implementada; primeiro precisamos definir os endpoints e permissões da API aberta do Scopi.
- Os dados de agenda são locais neste primeiro MVP. Não há sincronização entre aparelhos.

## Abrir o Android
1. Instale o Android Studio.
2. Abra a pasta `android` como projeto.
3. Aguarde o Gradle sincronizar e execute em um aparelho Android ou emulador.
4. No Android 13 ou superior, permita notificações quando solicitado.

## Conectar o app ao backend GPT
1. Hospede o backend em um endereço HTTPS.
2. Abra “Falar com o Agente Gestor” no app e informe a URL base (sem `/api/assistant`); o app acrescenta essa rota automaticamente.
3. O backend atual responde a perguntas, mas ainda não executa ações sobre a agenda local. A próxima etapa será implementar comandos estruturados e confirmação antes de criar/alterar tarefas.

## Configurar o backend GPT
1. Instale Node.js 20+.
2. Entre na pasta `backend` e execute `npm install`.
3. Copie `.env.example` para `.env` e configure `OPENAI_API_KEY`.
4. Execute `npm start`.
5. Antes de uso real, configure autenticação, HTTPS e hospedagem segura. Não publique este servidor sem proteção.

O app e o backend são um ponto de partida técnico, não uma integração pronta com um GPT personalizado do ChatGPT. As instruções do agente gestor deverão ser incorporadas ao backend.
