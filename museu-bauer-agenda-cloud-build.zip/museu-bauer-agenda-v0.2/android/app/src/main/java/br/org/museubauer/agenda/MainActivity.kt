package br.org.museubauer.agenda

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.*

data class MuseumTask(val id: Long, val title: String, val details: String, val dueAt: Long, val priority: String, val done: Boolean = false)

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MuseumAgendaApp(this) }
    }
    private fun createNotificationChannel() {
        val channel = NotificationChannel("museu_lembretes", "Lembretes do Museu", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Avisos de tarefas e compromissos do Museu Mestre Bauer"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

@Composable
fun MuseumAgendaApp(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences("museu_agenda", Context.MODE_PRIVATE) }
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var showAdd by remember { mutableStateOf(false) }
    var showAssistant by remember { mutableStateOf(false) }
    val today = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("pt", "BR")).format(Date())

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFFB85C16), secondary = androidx.compose.ui.graphics.Color(0xFF365B4A), background = androidx.compose.ui.graphics.Color(0xFFFFF9F2))) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background, floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = androidx.compose.ui.graphics.Color.White) { Icon(Icons.Default.Add, contentDescription = "Adicionar tarefa") }
        }) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 90.dp)) {
                item {
                    Text("MUSEU MESTRE BAUER", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Agenda do Museu", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text(today.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondary)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null, tint = androidx.compose.ui.graphics.Color.White); Spacer(Modifier.width(8.dp)); Text("Painel de prioridades", color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.height(8.dp))
                            Text("${tasks.count { !it.done }} tarefas pendentes · ${tasks.count { !it.done && isToday(it.dueAt) }} para hoje", color = androidx.compose.ui.graphics.Color.White)
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { showAssistant = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = androidx.compose.ui.graphics.Color.White)) { Icon(Icons.Default.SmartToy, null); Spacer(Modifier.width(8.dp)); Text("Falar com o Agente Gestor") }
                        }
                    }
                }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.NotificationsActive, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text("Próximas tarefas", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } }
                if (tasks.isEmpty()) item { EmptyTasksCard() }
                items(tasks.sortedWith(compareBy<MuseumTask> { it.done }.thenBy { it.dueAt }), key = { it.id }) { task ->
                    TaskCard(task, onToggle = {
                        val updated = tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }
                        tasks = updated
                        saveTasks(prefs, tasks)
                        if (task.done) scheduleReminder(context, updated.first { it.id == task.id })
                        else cancelReminder(context, task.id)
                    }, onDelete = {
                        cancelReminder(context, task.id)
                        tasks = tasks.filterNot { it.id == task.id }
                        saveTasks(prefs, tasks)
                    })
                }
            }
        }
    }
    if (showAdd) AddTaskDialog(onDismiss = { showAdd = false }, onSave = { title, details, dueAt, priority ->
        val task = MuseumTask(System.currentTimeMillis(), title, details, dueAt, priority)
        tasks = tasks + task; saveTasks(prefs, tasks); scheduleReminder(context, task); showAdd = false
    })
    if (showAssistant) AssistantInfoDialog(
        context = context,
        prefs = prefs,
        onDismiss = { showAssistant = false }
    )
}

@Composable fun EmptyTasksCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(8.dp)); Text("Tudo organizado por aqui", fontWeight = FontWeight.SemiBold)
            Text("Toque em + para criar a primeira tarefa ou lembrete.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable fun TaskCard(task: MuseumTask, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(task.title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                if (task.details.isNotBlank()) Text(task.details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(SimpleDateFormat("dd/MM · HH:mm", Locale("pt", "BR")).format(Date(task.dueAt)) + " · " + task.priority, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            TextButton(onClick = onDelete) { Text("Excluir") }
        }
    }
}

@Composable fun AddTaskDialog(onDismiss: () -> Unit, onSave: (String, String, Long, String) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var details by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Normal") }
    var dueAt by remember { mutableLongStateOf(System.currentTimeMillis() + 60 * 60_000L) }
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale("pt", "BR")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Novo lembrete") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it },
                    label = { Text("Tarefa ou compromisso") }, singleLine = true)
                OutlinedTextField(value = details, onValueChange = { details = it },
                    label = { Text("Detalhes (opcional)") })
                Text("Data e horário do lembrete", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = dueAt }
                        DatePickerDialog(context, { _, year, month, day ->
                            val updated = Calendar.getInstance().apply {
                                timeInMillis = dueAt
                                set(Calendar.YEAR, year); set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, day)
                            }
                            dueAt = updated.timeInMillis
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(dateFormat.format(Date(dueAt)))
                    }
                    OutlinedButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = dueAt }
                        TimePickerDialog(context, { _, hour, minute ->
                            val updated = Calendar.getInstance().apply {
                                timeInMillis = dueAt
                                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            dueAt = updated.timeInMillis
                        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
                    }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(timeFormat.format(Date(dueAt)))
                    }
                }
                Text("Prioridade")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Baixa", "Normal", "Alta").forEach { p ->
                        FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && dueAt > System.currentTimeMillis(),
                onClick = { onSave(title.trim(), details.trim(), dueAt, priority) }) { Text("Salvar lembrete") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable fun AssistantInfoDialog(context: Context, prefs: android.content.SharedPreferences, onDismiss: () -> Unit) {
    var baseUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    var message by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Configure o endereço HTTPS do serviço seguro do agente para começar. A chave da OpenAI fica somente no servidor.") }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Default.SmartToy, null) },
        title = { Text("Agente Gestor") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Converse com o agente por meio de um backend seguro. O app não armazena a chave da OpenAI.")
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it.trim() },
                    label = { Text("Endereço HTTPS do serviço") },
                    placeholder = { Text("https://seu-servidor.exemplo") }, singleLine = true)
                OutlinedTextField(value = message, onValueChange = { message = it },
                    label = { Text("O que precisa organizar?") },
                    placeholder = { Text("Quais são minhas prioridades hoje?") }, minLines = 2)
                if (answer.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Text(answer, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && baseUrl.startsWith("https://") && message.isNotBlank(), onClick = {
                prefs.edit().putString("backend_url", baseUrl.trimEnd('/')).apply()
                busy = true
                val outgoing = message
                val endpoint = baseUrl.trimEnd('/') + "/api/assistant"
                Thread {
                    val result = try {
                        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                            doOutput = true
                            setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        }
                        connection.outputStream.use { it.write(JSONObject().put("message", outgoing).toString().toByteArray(Charsets.UTF_8)) }
                        val status = connection.responseCode
                        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                        val body = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                        connection.disconnect()
                        if (status in 200..299) JSONObject(body).optString("answer", "O agente não retornou texto.")
                        else "O serviço respondeu com erro ($status). Verifique o servidor."
                    } catch (_: Exception) {
                        "Não foi possível conectar. Confira o endereço HTTPS, a internet e se o backend está ativo."
                    }
                    (context as? Activity)?.runOnUiThread { answer = result; busy = false }
                }.start()
            }) { Text("Enviar ao GPT") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}

fun isToday(time: Long): Boolean {
    val a = Calendar.getInstance(); val b = Calendar.getInstance().apply { timeInMillis = time }
    return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}

fun saveTasks(prefs: android.content.SharedPreferences, tasks: List<MuseumTask>) {
    val array = JSONArray(); tasks.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("details", it.details).put("dueAt", it.dueAt).put("priority", it.priority).put("done", it.done)) }
    prefs.edit().putString("tasks", array.toString()).apply()
}
fun loadTasks(prefs: android.content.SharedPreferences): List<MuseumTask> = try {
    val arr = JSONArray(prefs.getString("tasks", "[]")); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); MuseumTask(o.getLong("id"), o.getString("title"), o.optString("details"), o.getLong("dueAt"), o.optString("priority", "Normal"), o.optBoolean("done")) }
} catch (_: Exception) { emptyList() }

fun reminderPendingIntent(context: Context, taskId: Long, title: String = "", details: String = ""): PendingIntent {
    val intent = Intent(context, ReminderReceiver::class.java)
        .putExtra("taskId", taskId).putExtra("title", title).putExtra("details", details)
    return PendingIntent.getBroadcast(context, taskId.hashCode(), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}

fun scheduleReminder(context: Context, task: MuseumTask) {
    if (task.done || task.dueAt <= System.currentTimeMillis()) return
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pending = reminderPendingIntent(context, task.id, task.title, task.details)
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.dueAt, pending)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.dueAt, pending)
        }
    } catch (_: SecurityException) {
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.dueAt, pending)
    }
}

fun cancelReminder(context: Context, taskId: Long) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pending = reminderPendingIntent(context, taskId)
    alarm.cancel(pending)
    pending.cancel()
}

class BootReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.MY_PACKAGE_REPLACED") return
        val prefs = context.getSharedPreferences("museu_agenda", Context.MODE_PRIVATE)
        loadTasks(prefs).filter { !it.done && it.dueAt > System.currentTimeMillis() }
            .forEach { scheduleReminder(context, it) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Lembrete do Museu"
        val details = intent.getStringExtra("details") ?: "Você tem uma tarefa agendada."
        val notification = NotificationCompat.Builder(context, "museu_lembretes").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(details.ifBlank { "Está na hora da sua tarefa." }).setStyle(NotificationCompat.BigTextStyle().bigText(details.ifBlank { "Está na hora da sua tarefa." })).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
        context.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}
